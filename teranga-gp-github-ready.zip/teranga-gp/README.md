# Teranga GP

Marketplace collaborative de transport de colis entre particuliers, pensée pour le marché sénégalais.

> **État du livrable :** socle MVP de développement. L'interface publique, le schéma PostgreSQL, les API de lecture/création, la validation et la configuration CI/Render sont fournis. Ce dépôt n'est **pas prêt à accepter des transactions réelles** : authentification, autorisation, vérification d'identité, paiement, assurance, modération et parcours de livraison doivent être intégrés et audités avant toute mise en production.

## Stack

- Next.js 15 App Router / React 19 / TypeScript
- PostgreSQL / Prisma 6
- Zod pour la validation des entrées
- Vitest pour les tests unitaires
- GitHub Actions pour les contrôles CI
- Render Blueprint pour le déploiement

## Prérequis

- Node.js 20.11+
- npm 10+
- Docker Desktop (ou PostgreSQL 16 local)
- Un compte GitHub et un compte Render pour le déploiement

## Démarrage local

```bash
cp .env.example .env
docker compose up -d db
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

Ouvrir http://localhost:3000.

Le endpoint `/api/health` vérifie la connexion PostgreSQL.

## Scripts

```bash
npm run dev
npm run build
npm run start
npm run lint
npm run typecheck
npm test
npm run db:studio
```

## API disponibles

### `GET /api/trips`

Filtres optionnels : `origin`, `destination`. Renvoie les trajets ouverts et futurs.

### `POST /api/trips`

Crée un trajet. Champs attendus : `travelerId`, `origin`, `destination`, `departureAt`, `availableWeightKg`, `pricePerKgXof`; `via`, `availableVolumeL`, `notes` optionnels.

### `GET /api/shipments`

Renvoie les demandes au statut `SEARCHING`.

### `POST /api/shipments`

Crée une demande. Champs attendus : `senderId`, `origin`, `destination`, `description`, `weightKg`; `declaredValueXof`, `desiredDate`, `budgetXof` optionnels.

**Important :** les endpoints POST actuels ne doivent pas être exposés en production sans authentification, autorisation basée sur l'utilisateur connecté, limitation de débit, protection anti-abus et journalisation. Les identifiants utilisateur transmis dans le body sont uniquement une facilité de développement et ne constituent pas une preuve d'identité.

## Structure

```text
src/
  app/
    api/health/
    api/trips/
    api/shipments/
    publier/
    trajets/
  components/
  lib/
prisma/
.github/workflows/
render.yaml
```

## Déploiement Render

1. Pousser ce dépôt sur GitHub.
2. Dans Render, choisir **New → Blueprint** et sélectionner le dépôt.
3. Vérifier les ressources proposées par `render.yaml` et les coûts du plan avant validation.
4. Renseigner `NEXT_PUBLIC_APP_URL` avec le domaine public HTTPS.
5. Laisser Render fournir `DATABASE_URL` depuis la base PostgreSQL liée.
6. Lancer le déploiement et vérifier `/api/health`.

Les migrations sont exécutées au démarrage via `prisma migrate deploy`. Pour une équipe ou une production critique, préférer une étape de release/migration contrôlée et un plan de rollback.

## Variables d'environnement

Voir `.env.example`. Ne jamais committer `.env`, clés API, secrets, credentials ou données personnelles.

## Sécurité et limites connues

Avant d'ouvrir le service au public, implémenter au minimum :

- Authentification robuste (OTP via fournisseur SMS, sessions sécurisées, récupération de compte).
- Contrôles d'accès serveur sur chaque objet et opération.
- Rate limiting distribué et protection contre le spam.
- Vérification d'identité via prestataire approprié, avec consentement et minimisation des données.
- Upload sécurisé et stockage privé des pièces justificatives et photos.
- Paiements via un prestataire autorisé au Sénégal, webhooks signés et idempotence.
- Workflow de litiges, preuves de remise, codes OTP/QR et journal d'audit.
- Politique des marchandises interdites et contrôle opérationnel.
- Conditions générales, politique de confidentialité et analyse juridique locale.
- Sauvegardes, alertes, monitoring, tests de charge et audit de sécurité.

Aucun portefeuille client, séquestre ou paiement n'est implémenté dans cette version.

## Données de démonstration

Les trajets affichés dans `/trajets` sont des exemples statiques clairement identifiés comme démonstration. Ils ne sont pas réservables et ne représentent pas des utilisateurs réels.

## Qualité

La CI exécute génération Prisma, vérification TypeScript, ESLint et tests Vitest. Elle ne remplace pas un test d'intégration avec une base PostgreSQL, un audit de sécurité ou un test de bout en bout en environnement de staging.
